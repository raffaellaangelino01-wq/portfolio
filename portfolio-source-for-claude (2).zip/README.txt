Portfolio Raffaella Angelino — pacchetto sorgente

Contenuto: index.html, style.css e immagini/.
Mantieni la cartella images accanto a index.html: il markup usa percorsi ./images/....
La cartella images include le foto del portfolio e i loghi locali degli strumenti.
Font e video YouTube richiedono una connessione internet.
